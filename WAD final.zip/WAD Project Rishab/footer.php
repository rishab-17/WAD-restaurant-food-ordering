﻿    <div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="aboutus.php">About</a></li>
                            <li><a href="register.php">Register</a></li>
                            <li><a href="menutest.php">Menu</a></li>
                            <li><a href="loginreg.php">Login</a></li>

                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Privacy</h3>
                        <ul>
                            <li><a href="profile.php">Profile</a></li>
                            <li><a href="cart.php">Cart</a></li>
                            <li><a href="reservation.php">Reservation</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>Contact Us</h3>
                        <p>
                            Address:&nbsp;Anand Rao Circle, Gandhi Nagar,
                            Banglore-560009
                        </p>
                        <p>
                            Contact:&nbsp;+91 9687874321
                        </p>
                        <p>
                            Gmail:&nbsp;presenta@gmail.com
                        </p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                    <p align="center"></p>
                </div>
                <p class="copyright">Presenta © 2022</p>
            </div>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>