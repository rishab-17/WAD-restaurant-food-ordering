﻿<?php
include('navbar.php');
?>

<!--corousal-->

<div id="carouselExampleControls"
         class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://cdn1.goibibo.com/voy_mmt/t_fs/htl-imgs/202107191902506712-31d23d94f3a811eba9d50a58a9feac02.jpg"
                     class="d-block w-100" alt="food">
            </div>
            <div class="carousel-item">
                <img src="https://cdn1.goibibo.com/voy_mmt/t_fs/htl-imgs/202107191902506712-2fccf412f3a811eb8e270a58a9feac02.jpg"
                     class="d-block w-100" alt="food">
            </div>
            <div class="carousel-item">
                <img src="https://cdn1.goibibo.com/voy_ing/t_fs/30306c40f3a811eb9fb60a58a9feac02.jpg"
                     class="d-block w-100" alt="food">
            </div>
        </div>
        <a class="carousel-control-prev"
           href="#carouselExampleControls"
           role="button" data-slide="prev">
           <span class="carousel-control-prev-icon"
                 aria-hidden="true">
           </span>
           <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next"
           href="#carouselExampleControls"
           role="button" data-slide="next">
           <span class="carousel-control-next-icon"
                 aria-hidden="true">
           </span>
           <span class="sr-only">Next</span>
        </a>
</div>

<!--section-->
<section class="about-section">
    <article>
            
        <p align="center" font family="Times New Roman">
            Although a great restaurant experience must include great food, a bad restaurant experience can be achieved through bad service alone.
        </p>
        <br><br>


        <p align="center">
            Although the skills aren’t hard to learn, finding the happiness
        </p>

    </article>
</section>





<?php
include('footer.php');
?>