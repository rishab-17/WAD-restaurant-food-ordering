﻿<?php
    include('admin_db.php');

    $id=$_GET['id'];

    $sql="DELETE FROM tbl_admin WHERE id=$id";

    $res=mysqli_query($conn,$sql);

    if($res==TRUE)
    {
        //query executed//admin deleted
        //create session variable
        $_SESSION['delete']="admin deleted successfully";
        echo "<script>window.location.href='sidebar_admin.php'</script>";
    }
    else
    {
        //failed to delete
        //echo 'failed to delete';
        $_SESSION['delete']="admin deletion failed";
        echo "<script>window.location.href='sidebar_admin.php'</script>";
    }

?>