<?php
	//Login Check
	if (!isset($_SESSION['user']))//if user session not set...redirect to login
	{
		$_SESSION['no-login-message']="<p align='center'><strong>Please Login Through Admin Page</strong></p>";
        echo "<script>window.location.href='admin_login.php'</script>";

	}
?>