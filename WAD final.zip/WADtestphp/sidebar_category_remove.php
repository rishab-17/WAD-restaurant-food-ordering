<?php
	
	include('admin_db.php');
	if (isset($_GET['id']) && isset($_GET['image_name']))
	{
		$id=$_GET['id'];
		$image_name=$_GET['image_name'];

		//delete physical file from folder
		/*if($image_name!="")
		{
			$path="WADtestphp/images/".$image_name.".jpg";

			$remove=unlink($path);

			if($remove==false)
			{
				//failed to remove image
				$_SESSION['remove']="error";
				//redirect to category
				echo "<script>window.location.href='sidebar_category.php'</script>";

				die();
			}
		}*/
		//delete data from database
		$sql="DELETE FROM tbl_category WHERE id=$id";

		$res=mysqli_query($conn,$sql);
		
		//check if data is deleted
		if($res==true)
		{
			//success
			//redirect
			$_SESSION['delete']="successfully deleted";
			echo "<script>window.location.href='sidebar_category.php'</script>";


		}
		else
		{
			//failure
			$_SESSION['delete']="failed to delete";
			//redirect

			echo "<script>window.location.href='sidebar_category.php'</script>";
		}
	}
	else
	{
		//redirect to category
		echo "<script>window.location.href='sidebar_category.php'</script>";
	}

?>