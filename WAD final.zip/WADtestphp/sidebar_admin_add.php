﻿<?php include('sidebar.php');?>
<style>
<?php include('sidebar_admin_table.css'); ?>
</style>

<br></br><br></br><br></br>

<?php
    if(isset($_SESSION['add']))
    {
        echo $_SESSION['add'];
        unset ($_SESSION['add']);
    }
    if(isset($_SESSION['delete']))
    {
        echo $_SESSION['delete'];
        unset ($_SESSION['delete']);
    }
?>
<form action=""  method="POST" >

    <table style="width:33%">
        <tr>
            <td>Full Name:</td>
            <td><input type="text" name="full_name" placeholder="Enter Name"></td>
        </tr>

        <tr>
            <td>Username:</td>
            <td><input type="text" name="username" placeholder="Enter Username"></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" name="password" placeholder="Enter Password"></td>
        </tr>


    <table>
    <input type="submit" name="submit" class="button_sub" value="Add Admin">

</form>
<br></br><br></br>

</body>
</html>



<?php
    
    if(isset($_POST['submit']))
    {
        //retrieving data from form
        $full_name=$_POST['full_name'];
        $username=$_POST['username'];
        $password=md5($_POST['password']);

        //sql query
        $sql="INSERT INTO tbl_admin SET
            full_name='$full_name',
            username='$username',
            password='$password'
        ";


        //executing query and saving into db
        $res=mysqli_query($conn, $sql) or die(mysqli_error());


        //check if data is inserted or not and display msg
        if($res==true)
        {
            //echo("data inserted");
            
            //creating a session variable
            $_SESSION['add']="Admin added successfully!";
            
            //redirect page
            echo "<script>window.location.href='sidebar_admin.php'</script>";

        }
        else
        {   //echo("not inserted");
            
            //creating a session variable
            $_SESSION['add']="Failed to add admin!";
            
            //redirect page to Add Admin
            echo "<script>window.location.href='sidebar_admin_add.php'</script>";
        }
    
    }
    
    

?>