﻿<?php include('sidebar.php') ?>
<style>
<?php include('sidebar_admin_table.css'); ?>
</style>

<br><br><br><br><br>


<p align="center" style="font-size:20px";>
Order From Rishab R
<br>
Username:&nbsp;hello
</p> 
<br><br>


<table style="width:100%">
<tr>
        <th style="width:20%;">Quantity</th>
        <th style="width:20%;">Title</th>
        <th style="width:20%;">Price</th>
</tr>
                    <?php
            
                        $username=$_SESSION['user'];


                        $conn=mysqli_connect('localhost','root','') or die(mysqli_error());
                        $db_select=mysqli_select_db($conn,'signupform') or die(mysqli_error());

                        $sql="SELECT * FROM tbl_cart WHERE username='$username'";

                        $res=mysqli_query($conn,$sql);

                        if($res==TRUE)
                        {
                            //count rows to chk if we have data in database
                            $count = mysqli_num_rows($res);
                            $sn=1;

                            if($count>0)
                            {
                                //data present in database
                                while($rows=mysqli_fetch_assoc($res))//get all rows and store in rows variable
                                {
                                    $id=$rows['id']; 
                                    $title=$rows['title'];
                                    $price=$rows['price'];
                                    $quantity=$rows['quantity'];
                                    $image_name=$rows['img'];

                                    //display the values in the table
                                    ?>
                                    <tr>
                                    <div class="product">

                                    <td><p class="product-quantity">Qnt: &nbsp;<?php echo $quantity;?> </td>

                                    <div class="product-info">
                                    <td><h3 class="product-name"><?php echo $title;?></h3></td>

                                    <!--h4 class="product-price">₹<?php echo $price;?></h4-->
                                    <?php $total=$price*$quantity; ?>

                                    <td><h4 class="product-price">Total:&nbsp;₹<?php echo $total;?></h4></td>

                                    </tr>

                                </div>

                            </div>

                                    <?php
                                    $sn++;
                                }


                            }
                            else{
                                //data not present
                            }
         

                        }

                    ?>
</table>
<br>
<p align="center" style="font-size:30px";><b>GrandTotal: &nbsp;Rs.300.00</b></p>
