﻿<?php include('sidebar.php'); ?>
<style>
<?php include('sidebar_admin_table.css'); ?>
</style>

<br></br><br></br><br></br>

<?php
    if(isset($_SESSION['add']))
    {
        echo $_SESSION['add'];
        unset ($_SESSION['add']);
    }
    if(isset($_SESSION['upload']))
    {
        echo $_SESSION['upload'];
        unset ($_SESSION['upload']);
    }
    if(isset($_SESSION['delete']))
    {
        echo $_SESSION['delete'];
        unset ($_SESSION['delete']);
    }
?>


<form action=""  method="POST" enctype="multipart/form-data" >

    <table style="width:33%">
        <tr>
            <td> Title:</td>
            <td><input type="text" name="title" placeholder="Enter Title"></td>
        </tr>

        <tr>
            <td>Image:</td>
            <td><input type="file" name="image" placeholder=" Choose File"></td>
        </tr>
        


    <table>
    <input type="submit" name="submit" class="button_sub" value="Add Catgory">

</form>
<br></br><br></br>

<?php
    if(isset($_POST['submit']))
    {
        $title=$_POST['title'];

        //check if the image is selected
        //print_r($_FILES['image']);
        //die();
        if(isset($_FILES['image']['name']))
        {
            //upload image
            //require image name, source path, destination
            $image_name=$_FILES['image']['name'];

            //renaming image
            //get extension of image(jpg, png...)
            //$ext=end(explode(".",$image_name));

            //rename the image
            $image_name="WAD_project_".rand(000,999);//.'.'.'jpg';
            
            /*$source_path=$_FILES['image']['tmp_name'];
            
            $destination_path="WADtestphp/images/".$image_name;

            //upload image
            $upload=move_uploaded_file($source_path, $destination_path);
            
            //check whether image is uploaded
            if($upload==FALSE)
            {
                $_SESSION['upload']="failed to upload message";
                //redirect to add category
                echo"<script>window.location.href='sidebar_category_add.php'</script>";
                //stop process
                die();
            }
        }
        else
        {
            //dont upload
            $image_name="";
        }*/
        }

        $sql="INSERT INTO tbl_category SET
                title='$title',
                img_name='$image_name'
        ";

        $res=mysqli_query($conn,$sql) or die(mysqli_error());

        if($res==TRUE)
        {
            //success and redirect
            $_SESSION['add']= "Successfully added";
            echo "<script>window.location.href='sidebar_category.php'</script>";
        }
        else
        {
            //failure and redirect to same
            $_SESSION['add']= "Failed To Add";
            echo "<script>window.location.href='sidebar_category_add.php'</script>";

        }

    }
?>