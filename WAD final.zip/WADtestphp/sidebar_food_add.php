﻿<?php include('sidebar.php'); ?>
<style>
<?php include('sidebar_admin_table.css'); ?>
</style>

<br></br><br></br><br></br>
<?php
    if(isset($_SESSION['upload']))
    {
        echo $_SESSION['upload'];
        unset ($_SESSION['upload']);
    }
?>

<form action=""  method="POST" enctype="multipart/form-data" >

    <table style="width:33%">
        <tr>
            <td> Title:</td>
            <td><input type="text" name="title" placeholder="Enter Title"></td>
        </tr>

        <tr>
            <td> Description:</td>
            <td><textarea name="description"  placeholder="Enter Description"></textarea></td>
        </tr>

        <tr>
            <td> Price:</td>
            <td><input type="number" name="price" ></td>
        </tr>

        <tr>
            <td>Image:</td>
            <td><input type="file" name="image" placeholder=" Choose File"></td>
        </tr>

        <tr>
            <td> Category:</td>
            <td><select name="category">
                <?php
                    //categories from database
                    $sql="SELECT * FROM tbl_category";

                    $res=mysqli_query($conn, $sql);

                    $count=mysqli_num_rows($res);

                    if($count>0)
                    {
                        //have categories
                        
                        while($row=mysqli_fetch_assoc($res))
                        {
                            //get category details
                            $id=$row['id'];
                            $title=$row['title'];
                            
                            ?>
                            <option value="<?php echo $id ;?>"><?php echo $title ;?></option>

                            <?php
                        }
                    }
                    else
                    {
                        //no categories
                        ?>
                        <option value="0">No Categories Found</option>

                        <?php
                    }
                
                ?>
                
            </td>
        </tr>
        


    <table>
    <input type="submit" name="submit" class="button_sub" value="Add Food">
</form>
<br></br><br></br>

<?php

    if(isset($_POST['submit']))
    {
        //add food to database
        $title=$_POST['title'];
        $description=$_POST['description'];
        $price=$_POST['price'];
        $category=$_POST['category'];

        //details of image
        if(isset($_FILES['image']['name']))
        {

            //get details if button selected
            $image_name=$_FILES['image']['name'];

            //
            $image_name="WAD_food".rand(000,999);//.".".$ext;

            
            //upload image only if image selected
            /*if($image_name!="")
            {
                //image selected
                $ext=end(explode('.',$image_name));

                //rename image

                $src=$_FILES['image']['tmp_name'];

                $dst="images/".$image_name;

                $upload=move_uploaded_file($src,$dst);

                if($upload==false)
                {
                    //failed to upload
                    $_SESSION['upload']="failed to upload image";
                    echo "<script>window.location.href='sidebar_food.php'</script>";
                    die();
                }
            }
            
        }
        else
        {
            $image_name="";//default blank
        }*/
        }
        $sql2="INSERT INTO tbl_food SET
                title='$title',
                description='$description',
                price=$price,
                image_name='$image_name',
                category_id=$category
        ";

        $res2=mysqli_query($conn, $sql2);

        if($res2==true)
        {
            $_SESSION['add']="Food added successfully";
            echo "<script>window.location.href='sidebar_food.php'</script>";
        }
        else
        {
            $_SESSION['add']="Food failed to add";
            echo "<script>window.location.href='sidebar_food_add.php'</script>";

        }
    }

?>