﻿<?php include('sidebar.php'); ?>
<style>
<?php include('sidebar_admin_table.css'); ?>
</style>
<br><br><br><br><br><br>

<?php
        if(isset($_SESSION['add']))
        {
            echo $_SESSION['add'];
            unset($_SESSION['add']);
        }
        if(isset($_SESSION['remove']))
        {
            echo $_SESSION['remove'];
            unset ($_SESSION['remove']);
        }
        if(isset($_SESSION['delete']))
        {
            echo $_SESSION['delete'];
            unset ($_SESSION['delete']);
        }
?>


<p align="center">
<a href="sidebar_category_add.php" class="button">Add Category</a>
</p>


<br><br>


<table style="width:100%">
<tr>
        <th>S.No.</th>
        <th>Title</th>
        <th>Image</th>
        <th>Action</th>
</tr>

<?php
    //to get all admins
    $sql="SELECT * FROM tbl_category";

    $res=mysqli_query($conn,$sql);

    if($res==TRUE)
    {
        //count rows to chk if we have data in database
        $count = mysqli_num_rows($res);

        $sn=1;
        if($count>0)
        {
            //data present in database
            while($rows=mysqli_fetch_assoc($res))//get all rows and store in rows variable
            {
                $id=$rows['id']; 
                $title=$rows['title'];
                $image_name=$rows['img_name'];

                //display the values in the table
                ?>
                <tr>
                     <td><?php echo $sn++ ?></td>
                     <td><?php echo $title ?></td>


                
                     <td>
                        <?php 
                            //chk if omage name is available
                            if($image_name!="")
                            {
                                //display image
                                ?>
                                    <img src="images/category/<?php echo $image_name.'.jpg';?>" width="100px">
                                <?php
                            }
                            else
                            {
                                echo "no image added";
                            }
                        ?>
                     </td>
                     <td><a href="http://localhost/WADtestphp/sidebar_category_remove.php?id=<?php echo $id ;?>&image_name=<?php echo $image_name ;?>" class="buttons">Remove</a></td>
                </tr>

                <?php
            }


        }
        else{
            //data not present
        }
         

    }

?>
</table>
