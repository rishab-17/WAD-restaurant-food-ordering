<?php
		include('admin_db.php');
		//destroy session
		session_destroy();
		//redirect to login
		echo "<script>window.location.href='admin_login.php'</script>";
?>