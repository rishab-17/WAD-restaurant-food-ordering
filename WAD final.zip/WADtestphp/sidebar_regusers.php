﻿<?php include('sidebar.php'); ?>
<style>
<?php include('sidebar_admin_table.css'); ?>
</style>
<br><br><br><br>

<p align="center" style="font-size:30px"><strong>Registered Users:</strong></p>
<br><br><br>

<?php
    if(isset($_SESSION['delete']))
        {
            echo $_SESSION['delete'];
            unset ($_SESSION['delete']);
        }
?>


<table>
<tr>
        <th style="width:15%">ID</th>
        <th style="width:15%">Name</th>
        <th style="width:15%" >Username</th>
        <th style="width:15%">Email</th>
        <th style="width:15%">Contact</th>
        <th style="width:15%"> Address</th>
        <th style="width:15%">Action</th>
</tr>

<?php
            
    $conn=mysqli_connect('localhost','root','') or die(mysqli_error());
    $db_select=mysqli_select_db($conn,'signupform') or die(mysqli_error());
    
    //to get all users
    $sql="SELECT * FROM tbl_register";

    $res=mysqli_query($conn,$sql);

    if($res==TRUE)
    {
        //count rows to chk if we have data in database
        $count = mysqli_num_rows($res);

        $sn=1;
        if($count>0)
        {
            //data present in database
            while($rows=mysqli_fetch_assoc($res))//get all rows and store in rows variable
            {
                $id=$rows['id']; 
                $first_name=$rows['first_Name'];                               
                $username=$rows['username'];
                $last_name=$rows['last_Name'];
                $email=$rows['email'];
                $phone=$rows['phone'];
                $address=$rows['address'];

                //display the values in the table
                ?>
                <tr>
                     <td><?php echo $sn++ ?></td>
                     <td><?php echo $first_name." ".$last_name ?></td>
                     <td><?php echo $username ?></td>
                     <td><?php echo $email ?></td>
                     <td><?php echo $phone ?></td>
                     <td><?php echo $address ?></td>

                     <td><a href="http://localhost/WADtestphp/sidebar_regusers_remove.php?id=<?php echo $id ?>" class="buttons">Remove</a></td>
                </tr>

                <?php
            }


        }
        else{
            //data not present
        }
         

    }

?>
</table>