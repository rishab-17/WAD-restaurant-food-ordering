﻿<?php include('sidebar.php'); ?>
<style>
<?php include('sidebar_admin_table.css'); ?>
</style>

<br></br><br></br><br></br>
<?php
    if(isset($_SESSION['add']))
    {
        echo $_SESSION['add'];
        unset ($_SESSION['add']);
    }
    if(isset($_SESSION['upload']))
    {
        echo $_SESSION['upload'];
        unset ($_SESSION['upload']);
    }
    if(isset($_SESSION['delete']))
    {
        echo $_SESSION['delete'];
        unset ($_SESSION['delete']);
    }
?> 



<p align="center">
<a href="sidebar_food_add.php" class="button">Add Food</a>
</p> 


<br><br>

<table style="width:100%">
<tr>
        <th style="width:20%;">S.No.</th>
        <th style="width:20%;">Title</th>
        <th style="width:20%;">Price</th>
        <th style="width:20%;">Action</th>
</tr>
<?php
    $sql="SELECT * FROM tbl_food";

    $res=mysqli_query($conn,$sql);

    $count=mysqli_num_rows($res);

    if($count>0)
    {
        //food in db
        $sn=1;
        while($row=mysqli_fetch_assoc($res))//get all rows and store in rows variable
        {
            $id=$row['id'];
            $title=$row['title'];
            $price=$row['price'];
            $image_name=$row['image_name']

            ?>
            <tr>
            <td><?php echo $sn++ ; ?></td>
            <td><?php echo $title ;?></td>
            <td><?php echo $price ;?></td>
            
            <td><a href="http://localhost/WADtestphp/sidebar_food_remove.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name ;?>" class="buttons">Remove</a></td>
            </tr>


            <?php

        } 
    }
    else
    {
        //no food in database
        echo"<tr><td>No food added</td></tr>";
    }


?>
</table>







