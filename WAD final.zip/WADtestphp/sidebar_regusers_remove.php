﻿<?php
    
    $conn=mysqli_connect('localhost','root','') or die(mysqli_error());
    $db_select=mysqli_select_db($conn,'signupform') or die(mysqli_error());
    
    $id=$_GET['id'];

    $sql="DELETE FROM tbl_register WHERE id=$id";

    $res=mysqli_query($conn,$sql);

    if($res==TRUE)
    {
        //query executed//user deleted
        //create session variable
        $_SESSION['delete']="User Deleted!";
        echo "<script>window.location.href='sidebar_regusers.php'</script>";
    }
    else
    {
        //failed to delete
        //echo 'failed to delete';
        $_SESSION['delete']="User Failed to Delete!";
        echo "<script>window.location.href='sidebar_regusers.php'</script>";        
    }

?>