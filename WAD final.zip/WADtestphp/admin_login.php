﻿<?php include('admin_db.php'); ?>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="admin_login.css">
    <title>Presenta Admin</title>
</head>
<body>
    <?php
            if(isset($_SESSION['login']))
            {
                echo $_SESSION['login'];
                unset($_SESSION['login']);
            }
            if(isset($_SESSION['no-login-message']))
            {
                echo $_SESSION['no-login-message'];
                unset($_SESSION['no-login-message']);
            }
    ?>



    <form action="" method="post">
  <div class="imgcontainer">
        <p style="font-size:25px;"align ="center">PRESENTA ADMIN LOGIN</p>
  </div>
  <br><br>

  <div class="container">
    <label for="uname"><b>Username:</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

    <label for="psw"><b>Password:</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

    <button type="submit" name="submit">Login</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw"> <a href="#">Forgot Password?</a></span>
  </div>
</form>

</body>
</html>


<?php
    if(isset($_POST['submit']))
    {
        $username=$_POST['username'];
        $password=md5($_POST['password']);

        $sql="SELECT * FROM tbl_admin WHERE username='$username' AND password='$password'";

        $res=mysqli_query($conn,$sql);

        $count=mysqli_num_rows($res);
        if($count==1)
        {
            //user exists and login success
            $_SESSION['login']="<stong>Login Successful!</strong>";
            //user logged in;
            $_SESSION['user']=$username;
           
            
            //redirect to dashboard
            echo "<script>window.location.href='admintest.php'</script>";
            

        }
        else
        {
            //not available
            $_SESSION['login']="<p align='center' color='red'>Login Failed!<br>Invalid username or password!</p>";
            //redirect to same page
            echo "<script>window.location.href='admin_login.php'</script>";

        }
    }
?>