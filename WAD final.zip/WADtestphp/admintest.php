﻿<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin.css">
</head>

<body>
    <div class="sidebar">
        <div class="logo-details">
                    <i class='bx bx-grid-alt'></i>
            <span class="logo_name">Presenta</span>
        </div>
        <ul class="nav-links">
            <li>
                <a href="admintest.php" class="active">
                    <i class='bx bx-grid-alt'></i>
                    <span class="links_name">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="sidebar_admin.php">
                    <i class='bx bx-box'></i>
                    <span class="links_name">Admin</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class='bx bx-list-ul'></i>
                    <span class="links_name">Order</span>
                </a>
            </li>
            <li>
                <a href="sidebar_category.php">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Category</span>
                </a>
            </li>
            <li>
                <a href="sidebar_food.php">
                    <i class='bx bx-coin-stack'></i>
                    <span class="links_name">Food</span>
                </a>
            </li>

            <li>
                <a href="sidebar_regusers.php">
                    <i class='bx bx-book-bookmark'></i>
                    <span class="links_name">Registered Users</span>
                </a>
            </li>
            
                <li class="log_out">
                <a href="admin_logout.php">
                    <i class='bx bx-log-out'></i>
                    <span class="links_name">Log out</span>
                </a>
            </li>
        </ul>
    </div>
    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <i class='bx bx-menu sidebarBtn'></i>
                <span class="dashboard">Dashboard</span>
            </div>
            <div class="search-box">
                <input type="text" placeholder="Search...">
                <i class='bx bx-search'></i>
            </div>
            <div class="profile-details">
                <!--<img src="images/profile.jpg" alt="">-->
                <span class="admin_name">Rishab</span>
                <i class='bx bx-chevron-down'></i>
            </div>
        </nav>
         <br /><br /><br /><br>
         <?php include('admin_db.php');
          include('admin_user_login.php');  
    ?>
       
        <?php
            if(isset($_SESSION['login']))
            {
                echo $_SESSION['login'];
                unset ($_SESSION['login']);
            }

        ?>
       
        <div class="home-content">
            <div class="overview-boxes">
                <div class="box">
                    <div class="right-side">
                        <div class="box-topic">Total Order</div>
                        <div class="number">2</div>
                        <div class="indicator">
                            <i class='bx bx-up-arrow-alt'></i>
                            <span class="text">Up</span>
                        </div>
                    </div>
                    <i class='bx bx-cart-alt cart'></i>
                </div>
                <div class="box">
                    <div class="right-side">
                        <div class="box-topic"> Categories</div>
                        <div class="number">4</div>
                        <div class="indicator">
                            <i class='bx bx-up-arrow-alt'></i>
                            <span class="text">Up</span>
                        </div>
                    </div>
                    <i class='bx bxs-cart-add cart two'></i>
                </div>
                <div class="box">
                    <div class="right-side">
                        <div class="box-topic">Total Users</div>
                        <div class="number">3</div>
                        <div class="indicator">
                            <i class='bx bx-up-arrow-alt'></i>
                            <span class="text">Up</span>
                        </div>
                    </div>
                    <i class='bx bx-cart cart three'></i>
                </div>
                <div class="box">
                    <div class="right-side">
                        <div class="box-topic"> Food Items</div>
                        <div class="number">16</div>
                        <div class="indicator">
                            <i class='bx bx-up-arrow-alt'></i>
                            <span class="text">Up</span>
                        </div>
                    </div>
                    <i class='bx bxs-cart-add cart two''></i>
                </div>
            </div>

            </div>
        </div>
    </section>

    <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
    </script>

</body>
</html>

