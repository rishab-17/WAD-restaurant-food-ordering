﻿<?php include('sidebar.php'); ?>

<style>
<?php include('sidebar_admin_table.css'); ?>
</style>
<br><br><br><br><br><br>

<?php
    if(isset($_SESSION['add']))
    {
        echo $_SESSION['add'];
        unset ($_SESSION['add']);
    }
    if(isset($_SESSION['delete']))
    {
        echo $_SESSION['delete'];
        unset ($_SESSION['delete']);
    }
     if(isset($_SESSION['login']))
    {
        echo $_SESSION['login'];
        unset ($_SESSION['login']);
    }
?>

<p align="center">
<a href="sidebar_admin_add.php" class="button">Add Admin</a>
</p>


<br><br>


<table style="width:100%">
<tr>
        <th>ID</th>
        <th>Admins</th>
        <th>Username</th>
        <th>Action</th>
</tr>

<?php
    //to get all admins
    $sql="SELECT * FROM tbl_admin";

    $res=mysqli_query($conn,$sql);

    if($res==TRUE)
    {
        //count rows to chk if we have data in database
        $count = mysqli_num_rows($res);

        $sn=1;
        if($count>0)
        {
            //data present in database
            while($rows=mysqli_fetch_assoc($res))//get all rows and store in rows variable
            {
                $id=$rows['id']; 
                $full_name=$rows['full_name'];
                $username=$rows['username'];

                //display the values in the table
                ?>
                <tr>
                     <td><?php echo $sn++ ?></td>
                     <td><?php echo $full_name ?></td>
                     <td><?php echo $username ?></td>
                     <td><a href="http://localhost/WADtestphp/sidebar_admin_remove.php?id=<?php echo $id ;?>" class="buttons">Remove</a></td>
                </tr>

                <?php
            }


        }
        else{
            //data not present
        }
         

    }

?>






</body>
</html>